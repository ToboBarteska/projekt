from django.apps import AppConfig


class HodnoceniConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hodnoceni'
